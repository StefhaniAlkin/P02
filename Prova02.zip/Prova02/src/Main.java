import data.*;
import model.Automovel;
import model.Caminhao;
import model.Proprietario;
import model.Veiculo;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        Proprietario proprietario1 = new Proprietario(1234, "Proprietario1", "111111");
        ProprietarioDAO propDao = new ProprietarioSQLiteDAO();
        propDao.salvar(proprietario1);

        Automovel auto1 = new Automovel(1111, "AAA1A11", "Fiat", proprietario1, 4, 5);
        AutomovelDAO autDao = new AutomovelSQLiteDAO();
        autDao.salvar(auto1);

        Caminhao caminhao1 = new Caminhao(2222, "BBB2B22", "Scania", proprietario1, 10000, 8000);
        CaminhaoDAO camDao = new CaminhaoSQLiteDAO();
        camDao.salvar(caminhao1);



        Veiculo veiculo1 = new Veiculo(1, "AAA1A11", "Fiat", proprietario1);
        VeiculoDAO veicDao = (VeiculoDAO) new VeiculoSQLiteDAO();
        veicDao.salvar(veiculo1);

        List<Proprietario> listProp = propDao.buscarTodos();
        for (Proprietario p : listProp){
            p.mostrarDados();
        }








    }
}
