package data;

public class VeiculoSQLiteDAO {
}
